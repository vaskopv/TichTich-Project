﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TichTich.Data.Migrations
{
    public partial class InidialModelAdd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
